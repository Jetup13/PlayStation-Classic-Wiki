#!/bin/sh
source "/var/volatile/project_eris.cfg"
cd "/media/project_eris/etc/project_eris/SUP/launchers/openjazz"
chmod +x "OpenJazz"
echo -n 2 > "/data/power/disable"
HOME="/media/project_eris/etc/project_eris/SUP/launchers/openjazz" SDL_GAMECONTROLLERCONFIG="$(cat ${PROJECT_ERIS_PATH}/etc/boot_menu/gamecontrollerdb.txt)" ./OpenJazz -f "$(pwd)/gamedata" &> "${RUNTIME_LOG_PATH}/jazzjackrabbit.log" 
echo -n 1 > "/data/power/disable"