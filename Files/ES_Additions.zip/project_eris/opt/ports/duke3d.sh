#!/bin/sh
source "/var/volatile/project_eris.cfg"
cd "/media/project_eris/etc/project_eris/SUP/launchers/duke3d"
chmod +x "eduke32"
echo -n 2 > "/data/power/disable"
./eduke32 -g "duke3d_sc55.zip" &> "${RUNTIME_LOG_PATH}/duke3d.log" 
echo -n 1 > "/data/power/disable"