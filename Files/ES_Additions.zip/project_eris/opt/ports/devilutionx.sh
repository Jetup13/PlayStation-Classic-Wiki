#!/bin/bash
source "/var/volatile/project_eris.cfg"
cd "/media/project_eris/etc/project_eris/SUP/launchers/devilutionx"
mv -f "DIABDAT.MPQ" "diabdat.mpq"
mv -f "diabdat.MPQ" "diabdat.mpq"
chmod +x ./devilutionx
echo -n 2 > "/data/power/disable"
rm /dev/input/event2
HOME="/media/project_eris/etc/project_eris/SUP/launchers/devilutionx" LD_LIBRARY_PATH="/media/project_eris/etc/project_eris/SUP/launchers/devilutionx:${LD_LIBRARY_PATH}" ./devilutionx > "/media/logs/devilutionx.log" 2>&1
for xhci in /sys/bus/pci/drivers/?hci_hcd ; do

  if ! cd $xhci ; then
    echo Weird error. Failed to change directory to $xhci
    exit 1
  fi

  echo Resetting devices from $xhci...

  for i in ????:??:??.? ; do
    echo -n "$i" > unbind
    echo -n "$i" > bind
  done
done
echo -n 1 > "/data/power/disable"