#!/bin/sh
source "/var/volatile/project_eris.cfg"
cd "/media/project_eris/etc/project_eris/SUP/launchers/wolf4sdl_sd"
chmod +x "wolf3d"
echo -n 2 > "/data/power/disable"
HOME="/media/project_eris/etc/project_eris/SUP/launchers/wolf4sdl_sd" ./wolf3d --resf 1280 720 > "${RUNTIME_LOG_PATH}/wolf3d_sd.log" 2>&1
echo -n 1 > "/data/power/disable"