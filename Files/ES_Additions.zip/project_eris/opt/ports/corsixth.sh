#!/bin/sh
source "/var/volatile/project_eris.cfg"
cd "/media/project_eris/etc/project_eris/SUP/launchers/corsixth"
chmod +x "corsix-th"
echo -n 2 > "/data/power/disable"
HOME="/media/project_eris/etc/project_eris/SUP/launchers/corsixth" LD_LIBRARY_PATH="${LD_LIBRARY_PATH}:/media/project_eris/etc/project_eris/SUP/launchers/corsixth/lib" SDL_GAMECONTROLLERCONFIG="$(cat ${PROJECT_ERIS_PATH}/etc/boot_menu/gamecontrollerdb.txt)" ./corsix-th &> "${RUNTIME_LOG_PATH}/corsixth.log" 
echo -n 1 > "/data/power/disable"