#!/bin/sh
source "/var/volatile/project_eris.cfg"
cd "/media/project_eris/etc/project_eris/SUP/launchers/ioquake3"
chmod +x "ioquake3.arm"
echo -n 2 > "/data/power/disable"
HOME="/media/project_eris/etc/project_eris/SUP/launchers/ioquake3" LD_LIBRARY_PATH="/media/project_eris/lib" LD_PRELOAD="${PROJECT_ERIS_PATH}/lib/sdl_remap_arm.so" ./ioquake3.arm &> "${RUNTIME_LOG_PATH}/quake3arena.log"
echo -n 1 > "/data/power/disable"
echo "launch_StockUI" > "/tmp/launchfilecommand"