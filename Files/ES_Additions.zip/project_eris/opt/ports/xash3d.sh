#!/bin/sh
source "/var/volatile/project_eris.cfg"
XASH_WORK_DIR="/media/project_eris/etc/project_eris/SUP/launchers/xash3d/xash"
cd "${XASH_WORK_DIR}"
chmod +x "xash3d"
echo -n 2 > "/data/power/disable"
XASH3D_BASEDIR="${XASH_WORK_DIR}" LD_LIBRARY_PATH="${XASH_WORK_DIR}" ./xash3d -dev 0 -fullscreen -log &> "${RUNTIME_LOG_PATH}/xash3d.log"
echo -n 1 > "/data/power/disable"