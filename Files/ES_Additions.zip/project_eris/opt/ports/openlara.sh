#!/bin/sh
source "/var/volatile/project_eris.cfg"
cd "/media/project_eris/etc/project_eris/SUP/launchers/openlara"
chmod +x "OpenLara"
echo -n 2 > "/data/power/disable"
LD_PRELOAD="${PROJECT_ERIS_PATH}/lib/sdl_remap_arm.so" ./OpenLara > "${RUNTIME_LOG_PATH}/openlara.log" 2>&1
echo -n 1 > "/data/power/disable"