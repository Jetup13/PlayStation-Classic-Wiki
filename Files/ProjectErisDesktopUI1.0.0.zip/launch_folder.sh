#!/bin/sh

echo 2 > /data/power/disable
echo XXXXXYYYYY > "/media/project_eris/etc/project_eris/CFG/selected_folder"
cd "/var/volatile/launchtmp"
echo "launch_StockUI" > "/tmp/launchfilecommand"
