#!/bin/sh

echo 2 > /data/power/disable
source "/var/volatile/project_eris.cfg"
PATH="$PATH:$bleemsync_path/bin"
mkdir -p "/tmp/ra_cache"
chmod +x /media/project_eris/opt/retroarch/retroarch
HOME=/media/project_eris/opt/retroarch /media/project_eris/opt/retroarch/retroarch --config "/media/project_eris/opt/retroarch/config/retroarch/retroarch.cfg" -L"/media/project_eris/opt/retroarch/config/retroarch/cores/XXXXXYYYYY" "/var/volatile/launchtmp/YYYYYXXXXX" -v &> "/media/logs/retroarch.log"
rm -rf "tmp/ra_cache"
